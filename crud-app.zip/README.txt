Cara Upload ke InfinityFree:

1. Buka https://infinityfree.net dan daftar akun
2. Buat akun hosting, lalu masuk ke File Manager → /htdocs
3. Upload dan extract semua file dari ZIP ini
4. Buat database dari panel MySQL → simpan nama db, user, dan password
5. Edit file config.php dan sesuaikan koneksi MySQL kamu
6. Import database.sql lewat phpMyAdmin
7. Buka link domain kamu (contoh: https://crudvalen.epizy.com)
